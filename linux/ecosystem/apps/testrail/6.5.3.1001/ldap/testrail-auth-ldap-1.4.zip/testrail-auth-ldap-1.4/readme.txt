TestRail LDAP Authentication
----------------------------

This script can be used to integrate TestRail with LDAP services to
implement single sign-on. Please read the comments at the beginning of
the file and visit the following web page to learn more about this
script:

http://docs.gurock.com/testrail-integration/auth-introduction

-- 
Copyright Gurock Software GmbH. All rights reserved.
http://www.gurock.com/ - contact@gurock.com
